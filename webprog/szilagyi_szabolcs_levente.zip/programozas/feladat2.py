print("2. feladat")

print(int(input("Adj meg egy számot (negatív a befejezéshez): ")))