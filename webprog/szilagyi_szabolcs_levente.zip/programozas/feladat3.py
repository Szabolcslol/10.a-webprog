print("3. feladat")

tantargyak = {"matematika": "Kiss Anna", "magyar": "Nagy Péter", "történelem": "Szabó János", "biológia": "Kovács Mária", "kémia": "Farkas László", "földrajz": "Németh Zoltán", "fizika": "Tóth Gábor", "informatika": "Kovács Éva", "testnevelés": "Horváth István", "rajz": "Szűcs Anna"}
valasz = {}
print(input("Melyik tantárgyhoz kíván jegyzetelni? (Enter a befejezéshez): "))
print(input("Adja meg a jegyzet szövegét: "))