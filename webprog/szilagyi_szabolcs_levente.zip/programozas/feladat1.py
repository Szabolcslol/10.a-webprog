print("1. feladat")

print(input("Mi a keresztneved? "))
print(int(input("Hány könyvet olvastál? ")))
print(int(input("Hány oldalt olvastál el összesen? ")))
